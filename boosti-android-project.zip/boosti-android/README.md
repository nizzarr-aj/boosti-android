# BOOSTI Android

Android wrapper for the BOOSTI website. The app opens the live BOOSTI site and keeps the same Supabase backend.

## Build APK
1. Upload this folder to a GitHub repository.
2. Open Actions → Build BOOSTI APK.
3. Run workflow.
4. Download the `BOOSTI-debug-apk` artifact.

The app uses the live site at https://nizzarr-aj.github.io/boosti/ .
